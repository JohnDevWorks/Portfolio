import { Canvas, useFrame } from '@react-three/fiber';
import { Float, MeshDistortMaterial, Stars, TorusKnot } from '@react-three/drei';
import { useRef } from 'react';

function Core() {
  const mesh = useRef();
  useFrame((state, delta) => {
    if (!mesh.current) return;
    mesh.current.rotation.x += delta * 0.12;
    mesh.current.rotation.y += delta * 0.2;
    mesh.current.rotation.z = state.pointer.x * 0.12;
  });
  return (
    <Float speed={1.2} rotationIntensity={0.28} floatIntensity={0.7}>
      <TorusKnot ref={mesh} args={[1.02, 0.29, 180, 24, 2, 5]}>
        <MeshDistortMaterial color="#77d9ff" roughness={0.16} metalness={0.72} distort={0.22} speed={1.7} emissive="#173d85" emissiveIntensity={0.55} />
      </TorusKnot>
    </Float>
  );
}

export default function Scene() {
  return (
    <div className="scene-wrap" aria-label="Animated 3D abstract blue torus sculpture">
      <Canvas camera={{ position: [0, 0, 5.2], fov: 42 }} dpr={[1, 1.6]} gl={{ alpha: true, antialias: true }}>
        <ambientLight intensity={1.2} />
        <pointLight position={[4, 3, 4]} intensity={32} color="#6ad7ff" />
        <pointLight position={[-4, -2, 1]} intensity={18} color="#7963ff" />
        <Stars radius={32} depth={18} count={700} factor={2} saturation={0.3} fade speed={0.35} />
        <Core />
      </Canvas>
      <div className="scene-ring ring-one" /><div className="scene-ring ring-two" />
      <div className="scene-caption"><span className="scene-pulse" /> COMMUNITY SYSTEMS / ONLINE</div>
    </div>
  );
}
