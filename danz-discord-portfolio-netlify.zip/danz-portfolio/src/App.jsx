import { useState } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { ArrowDownRight, ArrowRight, ArrowUpRight, Bot, Check, ChevronDown, Code2, Copy, Gamepad2, Mail, Menu, MessageCircle, ShieldCheck, Shield, Sparkles, Users, X } from 'lucide-react';
import Scene from './components/Scene.jsx';

const invite = 'https://discord.gg/dunkcitydynastyglo';
const email = 'airjordanzone2@protonmail.com';
const discord = 'Danzkieh';
const fadeUp = { hidden: { opacity: 0, y: 28 }, show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] } } };

function Reveal({ children, className = '', delay = 0 }) {
  const reduce = useReducedMotion();
  return <motion.div className={className} variants={fadeUp} initial="hidden" whileInView="show" viewport={{ once: true, amount: 0.18 }} transition={{ delay: reduce ? 0 : delay }}>{children}</motion.div>;
}

function Brand() {
  return <a className="brand" href="#top" aria-label="Danz home"><span className="brand-symbol">D<span>.</span></span><span className="brand-name">DANZ<span className="brand-slash">/</span></span></a>;
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const copyDiscord = async () => {
    try {
      await navigator.clipboard.writeText(discord);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch { window.location.href = `https://discord.com/users/`; }
  };
  const closeMenu = () => setMenuOpen(false);
  return (
    <div className="app-shell" id="top">
      <div className="ambient ambient-a" /><div className="ambient ambient-b" /><div className="grid-overlay" />
      <header className="header">
        <div className="header-inner"><Brand />
          <nav className={menuOpen ? 'nav nav-open' : 'nav'}>
            <a href="#about" onClick={closeMenu}>About</a><a href="#services" onClick={closeMenu}>Expertise</a><a href="#experience" onClick={closeMenu}>Experience</a><a href="#contact" onClick={closeMenu}>Contact</a>
          </nav>
          <a className="header-cta" href={invite} target="_blank" rel="noreferrer">Join the community <ArrowUpRight size={15} /></a>
          <button className="menu-button" aria-label={menuOpen ? 'Close navigation' : 'Open navigation'} onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X /> : <Menu />}</button>
        </div>
      </header>

      <main>
        <section className="hero section-wrap">
          <div className="hero-copy">
            <motion.div className="eyebrow" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .7 }}><span className="status-dot" /> DISCORD COMMUNITY SPECIALIST <span className="eyebrow-divider" /> OPEN TO OPPORTUNITIES</motion.div>
            <motion.h1 initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .8, delay: .12 }}>Building better<br /><span className="gradient-text">online communities.</span></motion.h1>
            <motion.p className="hero-intro" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: .8, delay: .28 }}>I'm <strong>Danz</strong> — a Discord community specialist focused on people, protection, and practical technology. I help create spaces where members feel welcome and teams can do their best work.</motion.p>
            <motion.div className="hero-actions" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .7, delay: .38 }}><a className="button button-primary" href="#experience">Explore my experience <ArrowDownRight size={17} /></a><a className="button button-ghost" href={`mailto:${email}`}>Let's talk <ArrowUpRight size={16} /></a></motion.div>
            <motion.div className="hero-stats" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: .55, duration: .8 }}><div><strong>03</strong><span>CORE SPECIALTIES</span></div><div><strong>01</strong><span>FEATURED GAME COMMUNITY</span></div><div><strong>∞</strong><span>ROOM TO BUILD</span></div></motion.div>
          </div>
          <div className="hero-visual"><Scene /><motion.div className="float-chip chip-community" animate={{ y: [0, -9, 0] }} transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}><span className="chip-icon purple"><Users size={16} /></span><span><b>Community</b><small>People come first</small></span><span className="chip-check"><Check size={13} /></span></motion.div><motion.div className="float-chip chip-automation" animate={{ y: [0, 8, 0] }} transition={{ duration: 5.8, repeat: Infinity, ease: 'easeInOut' }}><span className="chip-icon blue"><Code2 size={16} /></span><span><b>Automation</b><small>Smarter server systems</small></span><span className="chip-live" /></motion.div><div className="visual-label label-left">PEOPLE FIRST</div><div className="visual-label label-right">SYSTEMS THAT SCALE</div></div>
          <a className="scroll-cue" href="#about"><span /> SCROLL TO EXPLORE <ChevronDown size={13} /></a>
        </section>

        <section className="about section-wrap" id="about">
          <Reveal><div className="section-kicker">01 / THE PERSON BEHIND THE SERVER</div></Reveal>
          <div className="about-grid"><Reveal><h2>Good communities<br />don't happen <span className="muted-text">by accident.</span></h2></Reveal><Reveal delay={.12}><div className="about-copy"><p>I care about the experience behind every message, ticket, and interaction. My approach combines clear moderation standards, approachable communication, and practical systems that help communities stay organized as they grow.</p><p>From welcoming new members to handling difficult situations and building tools that reduce repetitive work, I focus on making the server better for both its members and its staff team.</p><div className="signature">DANZ <span>— COMMUNITY · TRUST · TECHNOLOGY</span></div></div></Reveal></div>
        </section>

        <section className="services section-wrap" id="services">
          <Reveal><div className="section-kicker">02 / WHAT I DO</div></Reveal>
          <div className="section-heading"><Reveal><h2>Community, with<br /><span className="muted-text">the right infrastructure.</span></h2></Reveal><Reveal delay={.12}><p className="section-side-note">A balanced mix of people skills and technical execution.</p></Reveal></div>
          <div className="service-grid">
            <Reveal delay={0}><article className="service-card"><div className="service-top"><span>01</span><div className="service-icon"><Users size={21} /></div></div><h3>Community Management</h3><p>Building welcoming spaces, coordinating staff, supporting members, and keeping communication clear and consistent.</p><div className="tag-row"><span>Engagement</span><span>Staff coordination</span><span>Community growth</span></div></article></Reveal>
            <Reveal delay={.1}><article className="service-card"><div className="service-top"><span>02</span><div className="service-icon"><Shield size={21} /></div></div><h3>Moderation & Safety</h3><p>Applying server rules fairly, handling reports and escalations, preventing disruption, and protecting the member experience.</p><div className="tag-row"><span>Rule enforcement</span><span>Ticket handling</span><span>Conflict resolution</span></div></article></Reveal>
            <Reveal delay={.2}><article className="service-card"><div className="service-top"><span>03</span><div className="service-icon"><Bot size={21} /></div></div><h3>Discord Bot Development</h3><p>Creating practical automation and custom bot features that make server operations smoother and more reliable.</p><div className="tag-row"><span>Automation</span><span>Server utilities</span><span>Custom workflows</span></div></article></Reveal>
          </div>
        </section>

        <section className="experience section-wrap" id="experience">
          <Reveal><div className="section-kicker">03 / FEATURED EXPERIENCE</div></Reveal>
          <Reveal delay={.1}><article className="experience-card">
            <div className="experience-art"><div className="art-grid" /><div className="dcd-mark"><span>D</span><b>CD</b></div><div className="art-bottom"><span>OFFICIAL GAME COMMUNITY</span><strong>DUNK CITY DYNASTY</strong></div><div className="art-orbit orbit-a" /><div className="art-orbit orbit-b" /></div>
            <div className="experience-content"><div className="experience-label"><span /> MODERATION EXPERIENCE</div>
              <div className="company-row"><div className="netease-brand"><img className="netease-official-logo" src="https://ir.netease.com/static-files/cc8ff364-73ee-4d20-b392-5a3db13a0d99" alt="NetEase logo" onError={(event) => { event.currentTarget.style.display = 'none'; event.currentTarget.nextElementSibling.style.display = 'block'; }} /><svg className="netease-fallback-mark" viewBox="0 0 42 42" role="img" aria-label="NetEase logo mark"><path d="M5 31V11l12 15V11h6v20L11 16v15H5Zm21 0V11h11v5h-5v3h5v5h-5v2h5v5H26Z" fill="currentColor"/><path d="M4 36h34" stroke="currentColor" strokeWidth="2" opacity=".5"/></svg><span><b>NetEase</b><small>GAMES</small></span></div><span className="role-pill">COMMUNITY MODERATOR</span></div>
              <h2>NetEase Games<br /><span className="muted-text">— Dunk City Dynasty</span></h2>
              <p>Moderator for the Dunk City Dynasty global Discord community, supporting a positive player environment through community moderation, member assistance, and day-to-day server care.</p>
              <div className="verified-row"><span className="verified-icon"><ShieldCheck size={17} /></span><span><b>Verified Discord server</b><small>Join the Dunk City Dynasty global community</small></span></div>
              <a className="button button-primary invite-button" href={invite} target="_blank" rel="noreferrer">Join Dunk City Dynasty <ArrowUpRight size={16} /></a>
              <a className="text-link" href="https://www.neteasegames.com/" target="_blank" rel="noreferrer">Visit NetEase Games <ArrowUpRight size={14} /></a>
            </div>
          </article></Reveal>
          <p className="disclaimer">NetEase Games and Dunk City Dynasty names and marks belong to their respective owners. This portfolio presents Danz's stated community role and is not an official NetEase website.</p>
        </section>

        <section className="contact section-wrap" id="contact">
          <Reveal><div className="contact-panel"><div className="contact-main"><div className="section-kicker">04 / START A CONVERSATION</div><h2>Let's build a<br /><span className="gradient-text">stronger community.</span></h2><p>Have a server to improve, a moderation team to support, or a bot idea to bring to life? Reach out and let's talk.</p><div className="contact-links"><a href={`mailto:${email}`}><span className="contact-icon"><Mail size={18} /></span><span><small>EMAIL</small>{email}</span><ArrowUpRight className="contact-arrow" size={17} /></a><button type="button" onClick={copyDiscord}><span className="contact-icon"><MessageCircle size={18} /></span><span><small>DISCORD USERNAME</small>{discord}</span><span className="copy-label">{copied ? <><Check size={14} /> COPIED</> : <><Copy size={13} /> COPY</>}</span></button></div></div><div className="contact-aside"><div className="aside-orb">D<span>.</span></div><div className="aside-note">GOOD PEOPLE.<br />GOOD SYSTEMS.<br /><span>BETTER COMMUNITIES.</span></div><div className="aside-meta">COMMUNITY OPERATIONS<br />EST. WITH PURPOSE</div></div></div></Reveal>
        </section>
      </main>
      <footer className="footer section-wrap"><Brand /><span>Designed for the people behind the communities.</span><span>© {new Date().getFullYear()} DANZ</span></footer>
      <a className="mobile-discord" href={invite} target="_blank" rel="noreferrer"><Gamepad2 size={16} /> Join community <ArrowUpRight size={14} /></a>
    </div>
  );
}

export default App;
