# Danz — Discord Community Portfolio

A responsive React portfolio built with Vite, React Three Fiber / Three.js, Framer Motion, and Lucide icons. It is configured for Netlify deployment.

## Run locally

```bash
npm install
npm run dev
```

## Build for production

```bash
npm run build
npm run preview
```

The production site is generated in `dist/`.

## Deploy to Netlify

1. Push this project folder to a GitHub repository.
2. In Netlify, choose **Add new site → Import an existing project** and select the repository.
3. Netlify reads `netlify.toml` automatically. The build command is `npm run build` and the publish directory is `dist`.
4. Deploy. No environment variables are required.

You can also drag the generated `dist/` folder into Netlify Drop after running `npm run build` locally.

## Personal details included

- Display name: Danz
- Discord: Danzkieh
- Email: airjordanzone2@protonmail.com
- Featured experience: NetEase Games — Dunk City Dynasty community moderator
- Community invite: https://discord.gg/dunkcitydynastyglo

## Notes

- The experience card attempts to load the NetEase-hosted logo and includes a vector fallback if the remote asset is unavailable.
- The page describes the Dunk City Dynasty server as verified based on the supplied information. NetEase Games and Dunk City Dynasty are trademarks of their respective owners. This is an independent portfolio, not an official NetEase website.
- The experience text is based on details supplied by the portfolio owner; update it if you want to add dates, achievements, or measurable outcomes.


## Reference

The initial inspiration link supplied for this portfolio was [MoncyDev/Portfolio-Website](https://github.com/MoncyDev/Portfolio-Website). This project is independently implemented and does not copy its source files.
